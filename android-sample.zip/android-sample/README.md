
This project demonstrates a simple Android app crearted by
Android Studio. The project also includes an example to 
show how to use dependency injection.
